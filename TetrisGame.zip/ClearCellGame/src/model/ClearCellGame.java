package model;

import java.util.Random;

/* This class must extend Game */
public class ClearCellGame extends Game {

	private int score = 0;
	Random random = new Random();
	

	public ClearCellGame(int maxRows, int maxCols, Random random, int strategy) {
		super(maxRows, maxCols);
		this.random = random;
		strategy = 1;

	}

	public boolean isGameOver() {
		if (isBoardRowEmpty(board.length - 1)) {
			return false;
		} else {
			return true;
		}

	}

	public int getScore() {

		return score++;

	}

	public void nextAnimationStep() {

		BoardCell[] temp = new BoardCell[this.getMaxCols()];

		if (!isGameOver()) {
			
			for(int i = 0; i <= board.length-1; i++) {
				int movingRow = board.length-1 -i;
				if(movingRow+1 < board.length) {
					board[movingRow+1] = board[movingRow];
				}
			}

			for (int col = 0; col < board[0].length; col++) {
				temp[col] = BoardCell.getNonEmptyRandomBoardCell(random);

				
			}
			board[0] = temp;
		}

	}

	

	public void processCell(int rowIndex, int colIndex) {

		int up = rowIndex - 1;
		int down = rowIndex + 1;
		int left = colIndex - 1;
		int right = colIndex + 1;
		

		if (!isGameOver()) {

		
			for (int direction = up; direction >= 0; direction--) {
				if (board[direction][colIndex].equals(board[rowIndex][colIndex])) {
					board[direction][colIndex] = BoardCell.EMPTY;
					score++;
				} else {
					break;
				}

			}
			
			for (int direction = down; direction <= board.length - 1; direction++) {
				if (board[direction][colIndex].equals(board[rowIndex][colIndex])) {
					board[direction][colIndex] = BoardCell.EMPTY;
					score++;
				} else {
					break;
				}
			}
			

			for (int direction = left; direction >= 0; direction--) {
				if (board[rowIndex][direction].equals(board[rowIndex][colIndex])) {
					board[rowIndex][direction] = BoardCell.EMPTY;
					score++;

				} else {

					break;
				}

			}
			
			for (int direction = right; direction <= board[0].length - 1; direction++) {
				if (board[rowIndex][direction].getColor().equals(board[rowIndex][colIndex].getColor())) {
					board[rowIndex][direction] = BoardCell.EMPTY;
					score++;
				} else {
					break;
				}
			}
			
			for (int directionUL = 1; colIndex - directionUL >= 0 && rowIndex - directionUL >= 0; directionUL++) {
				
				if (board[rowIndex - directionUL][colIndex - directionUL].equals(board[rowIndex][colIndex])) {
					board[rowIndex - directionUL][colIndex - directionUL] = BoardCell.EMPTY;
					score++;
				} else {
					break;
				}
			}

			
			for (int directionUR = 1; colIndex + directionUR < this.getMaxCols()
					&& rowIndex - directionUR >= 0; directionUR++) {
				
				if (board[rowIndex - directionUR][colIndex + directionUR].equals(board[rowIndex][colIndex])) {
					board[rowIndex - directionUR][colIndex + directionUR] = BoardCell.EMPTY;
					score++;
				} else {
					break;
				}

			}
			
			for (int directionDL = 1; colIndex - directionDL >= 0
					&& rowIndex + directionDL < this.getMaxRows(); directionDL++) {
				
				if (board[rowIndex + directionDL][colIndex - directionDL].equals(board[rowIndex][colIndex])) {
					board[rowIndex + directionDL][colIndex - directionDL] = BoardCell.EMPTY;
					score++;

				} else {
					break;
				}
			}
			// }
			// this clears the cell diagonal going down and right
			for (int directionDR = 1; colIndex + directionDR < this.getMaxCols()
					&& rowIndex + directionDR < this.getMaxRows(); directionDR++) {
				
				if (board[rowIndex + directionDR][colIndex + directionDR].equals(board[rowIndex][colIndex])) {
					board[rowIndex + directionDR][colIndex + directionDR] = BoardCell.EMPTY;
					score++;
				} else {
					break;
				}
			}
			
			board[rowIndex][colIndex] = BoardCell.EMPTY;
			score++;

		

			for (int row = 0; row < board.length - 1; row++) {
				if (isBoardRowEmpty(row)) {
					for (int i = row; i < board.length - 1; i++) {
						board[i] = board[i + 1];

					}
				}
			}
		}

	}

	private boolean isBoardRowEmpty(int row) {
		int colCount = 0;
		boolean boardRowEmpty = false;

		for (int col = 0; col < board[0].length; col++) {
			if (getBoardCell(row, col) == BoardCell.EMPTY) {
				colCount++;
			}

		}
		if (colCount == board[0].length) {
			boardRowEmpty = true;
		}
		return boardRowEmpty;
	}
	
	

}